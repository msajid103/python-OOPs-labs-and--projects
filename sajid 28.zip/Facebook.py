import openpyxl

wb = openpyxl.load_workbook("Facebook.xlsx")
ws = wb["Sheet1"]
ws2 = wb["Sheet2"]
ws3 = wb["Sheet3"]
ws4 = wb["Sheet4"]
ws5 = wb["Sheet5"]
ws2['A'][0].value = 'Full_NAME'
ws3['A'][0].value = 'Full_NAME'
ws4['A'][0].value = 'Full_NAME'
ws5['A'][0].value = 'Full_NAME'

header = ['Full_NAME', 'User_name', ' Date_birth', 'job', "study", 'status', 'other', 'Password', 'friendNotification',
          'messageNotification'
          '']
for i in range(1, len(header) + 1):
    ws.cell(row=1, column=i).value = header[i - 1]
wb.save('Facebook.xlsx')


class Facebook:
    def __init__(self):
        self.name = None
        self.user_name = None

    def signUp(self):
        self.name = input("write Full name")
        self.user_name = input("Write  user_name")
        flag = True
        for col in ws['B']:
            if col.value == self.user_name:
                flag = False
                print("This User already exist")
        if flag:
            ws.cell(row=ws.max_row + 1, column=1).value = self.name
            ws2.cell(row=1, column=ws2.max_column + 1).value = self.name
            ws3.cell(row=1, column=ws2.max_column).value = self.name
            ws4.cell(row=1, column=ws2.max_column).value = self.name
            ws5.cell(row=1, column=ws2.max_column).value = self.name
            ws.cell(row=ws.max_row, column=2).value = self.user_name
            ws.cell(row=ws.max_row, column=8).value = input("write Password")
            ws.cell(row=ws.max_row, column=3).value = input("write Date of Birth")
            ws.cell(row=ws.max_row, column=9).value = False
            ws.cell(row=ws.max_row, column=10).value = False
            wb.save("Facebook.xlsx")
            print("Your account SUCCESSFUL Created")

    def searchMember(self):

        name = input('write the name of member')
        flag = True
        for col in range(len(ws['A'])):
            if ws['A'][col].value == name:
                flag = False
                pre = int(input(f"For {name}'Profile press 1,For Exit press 2 "))
                if pre == 1:
                    for j in range(1, 8):
                        print(ws.cell(row=1, column=j).value, ":", end="")
                        print(ws.cell(row=col + 1, column=j).value)
                elif pre == 2:
                    User.functionalty(self)
                else:
                    print("Give correct input")

        if flag:
            print("This user not exist")


class User:

    def __init__(self):
        self.user_name = None
        self.loginStatus = False

        inp = input('Press 1 for Login or 2 fo Signup')
        if inp == '1':
            User.login(self)
        elif inp == '2':
            Facebook.signUp(self)
        else:
            print('Wrong input')

    def login(self):
        self.user_name = input("Wtrite user_name")
        password = input("Wtrite password")
        for col in range(len(ws['B'])):
            if ws['B'][col].value == self.user_name and ws['H'][col].value == password:
                self.name = ws['A'][col].value
                self.i = col
                print("Successfully Login")
                self.loginStatus = True
                User.notification(self)
                wb.save("Facebook.xlsx")

        if not self.loginStatus:
            print("Wrong user name or password")
        if self.loginStatus:
            User.functionalty(self)

    def notification(self):
        if ws['I'][self.i].value:
            print("You have new friend request")
            ws['I'][self.i].value = False
        if ws['j'][self.i].value:
            print("You have new message")
            ws['j'][self.i].value = False

    def editinfo(self, a):
        for col in range(len(ws['B'])):
            if ws['B'][col].value == a:
                ws.cell(row=col + 1, column=4).value = input("Write  job")
                ws.cell(row=col + 1, column=5).value = input("write study")
                ws.cell(row=col + 1, column=6).value = input("write  Status")
                ws.cell(row=col + 1, column=7).value = input("write  other")
                wb.save("Facebook.xlsx")
                print("SUCCESSFUL profile edited")
        User.functionalty(self)

    def logOut(self):
        self.loginStatus = False
        print("Successfully Logout")

    def functionalty(self):
        pre = int(input("\nPress 1 for logout ,2 for edit profile,"
                        "\n3 for Search Member,4 for send request,"
                        "\n5 check friend request,6 for send message,"
                        "\n7 for posting,8 for commenting,"
                        "\n9 For view messages\n"))
        if pre == 1:
            User.logOut(self)
        elif pre == 2:
            User.editinfo(self, self.user_name)
        elif pre == 3:
            Facebook.searchMember(self)
        elif pre == 4:
            User.friendRequest(self)
        elif pre == 5:
            User.acceptrequest(self)
        elif pre == 6:
            User.send_message(self)
        elif pre == 7:
            User.send_post(self)
        elif pre == 8:
            User.comment_on_post(self)
        elif pre == 9:
            User.vewMessages(self)
        else:
            User.functionalty()
    def vewMessages(self):
        for i in range(2,ws4.max_row+1):
            print(ws4.cell(row= i, column=self.i+1).value)




    def friendRequest(self):
        name = input("Write the name of user:")
        flag = True
        for k in range(1,ws2.max_column):
            if ws2.cell(row=1, column=k).value == name and k != self.i + 1:
                if User.alreadyfriend(self,k):
                    ws.cell(row=k, column=9).value = True
                    flag = False
                    l = 1
                    while l <= ws2.max_row + 1:
                        if ws2.cell(row=l, column=k).value == None:
                            ws2.cell(row=l, column=k).value = self.name
                            print("Sended")
                            wb.save("Facebook.xlsx")
                            break
                        l += 1
                else:
                    print("you are already send friend request")
                k += 1
        if flag:
            print("This user dos't exist")
        User.functionalty(self)
    def alreadyfriend(self,a):
        for i in range(2,ws.max_row+1):
            if ws2.cell(row=i, column=a).value == self.name or ws3.cell(row=i, column=a).value == self.name:
                return False
        return True

    def acceptrequest(self):
        l = 1
        while l <= ws2.max_row + 1:
            val = ws2.cell(row=l + 1, column=self.i + 1).value
            if val != None:
                print(f'To accept the Friend request of {val}')
                pre = input('press 1,2 reject else press any key')
                if pre == '1':
                    ws2.cell(row=l + 1, column=self.i + 1).value = None
                    for m in range(ws3.max_row + 1):
                        if ws3.cell(row=m + 1, column=self.i + 1).value == None:
                            ws3.cell(row=m + 1, column=self.i + 1).value = val
                            k = 1
                            while k <= ws3.max_column:
                                if ws3.cell(row=1, column=k).value == val:
                                    li = 1
                                    while li <= ws3.max_row + 1:
                                        if ws3.cell(row=li + 1, column=k).value == None:
                                            ws3.cell(row=li + 1, column=k).value = self.name
                                            wb.save("Facebook.xlsx")
                                            print('accepted')
                                            break
                                        li += 1
                                k += 1
                elif pre == '2':
                    ws2.cell(row=l + 1, column=self.i + 1).value=None
                    print("rejected")
                    wb.save("Facebook.xlsx")

            l += 1
        User.functionalty(self)
    def send_message(self):
        flag = True
        message = str(input(" Type message ........ "))
        To = input(" TO : ")
        From = self.name
        for j in range(len(ws4['1'])):
            if ws4['1'][j].value == To:
                flag = False
                k = 1
                while k <= ws4.max_row+1:  # this while loop will enter new message in new  row of the user to whom message is send
                    print(k)
                    if ws4.cell(row= k, column=j+1).value == None:
                        ws4.cell(row= k, column=j+1).value = message + "   from  :  " + From
                        ws.cell(row=j+1, column=10).value = True
                        wb.save('Facebook.xlsx')
                        print('sended')
                        break
                    k += 1

        if flag:
            print(" ************ This user not exist! ********** ")
        User.functionalty(self)



    def send_post(self):
        print(" ....................... Welcome ", self.name, " !  To Posting ************************* ")

        k = 1
        while k <= ws5.max_row:
            if ws5.cell(row=k + 1, column=self.i+1).value == None:

                user_post_choice = input(" Write a post : ")
                ws5.cell(row=k + 1, column=self.i+1).value = user_post_choice
                wb.save("Facebook.xlsx")
                print("Posted Successfully")
                break
            k += 1
        User.functionalty(self)

    def comment_on_post(self):

            user = input("Enter the name of the person to whom post you want to comment : ")

            for E in range(len(ws5['1'])):
                if ws5['1'][E].value == user:
                    Y = 1
                    while Y <= ws5.max_row+1:
                        if ws5.cell(row= Y + 1, column=E+1).value == None:
                            print(" ---Post is : ", ws5.cell(row=Y, column=E+1).value)
                            user_comment = input(" Write your comment  : ")
                            ws5.cell(row=Y + 1, column=E+1).value = self.name + " commented : " + user_comment
                            wb.save("Facebook.xlsx")
                            break
                        Y += 1
                else:
                    print('This user not exit')



Facebook()
User()


